CREATE OR REPLACE PACKAGE BODY pkg_etl_dimensional AS

    -- Procedure para carregar a Dimensão Produto
    PROCEDURE etl_dim_produto IS
    BEGIN
        INSERT INTO Dim_Produto (id_produto, nm_produto, nm_categoria, nm_marca, vl_preco)
        SELECT DISTINCT 
            p.produto_id,
            p.nome_produto, 
            p.categoria, 
            p.marca,
            ROUND(p.preco, 2) -- Arredondar para duas casas decimais
        FROM Produto p;
    END etl_dim_produto;

    -- Procedure para carregar a Dimensão Cliente
    PROCEDURE etl_dim_cliente IS
    BEGIN
        INSERT INTO Dim_Cliente (id_cliente, nm_cliente, nm_email, dt_cadastro)
        SELECT DISTINCT
            c.cliente_id,
            c.nome_cliente,
            c.email,
            TO_CHAR(c.data_cadastro, 'DD-MM-YY')
        FROM Cliente c;
    END etl_dim_cliente;

    -- Procedure para carregar a Dimensão Loja
    PROCEDURE etl_dim_loja IS
    BEGIN
        INSERT INTO Dim_Loja (id_loja, nm_loja, ds_endereco, nm_regiao, cd_cep)
        SELECT DISTINCT 
            l.loja_id, 
            l.nome_loja,
            SUBSTR(l.localizacao_loja, 1, INSTR(l.localizacao_loja, ',', 1, 3) - 1) AS ds_endereco,
            SUBSTR(l.localizacao_loja, INSTR(l.localizacao_loja, ',', 1, 3) + 2, 
                INSTR(l.localizacao_loja, ',', 1, 4) - INSTR(l.localizacao_loja, ',', 1, 3) - 2) AS nm_regiao,
            -- Extrair apenas números e formatar o CEP
            CASE 
                WHEN LENGTH(REGEXP_REPLACE(SUBSTR(l.localizacao_loja, INSTR(l.localizacao_loja, ',', 1, 4) + 5), '[^0-9]', '')) = 8 THEN
                    SUBSTR(REGEXP_REPLACE(SUBSTR(l.localizacao_loja, INSTR(l.localizacao_loja, ',', 1, 4) + 5), '[^0-9]', ''), 1, 2) || '.' ||
                    SUBSTR(REGEXP_REPLACE(SUBSTR(l.localizacao_loja, INSTR(l.localizacao_loja, ',', 1, 4) + 5), '[^0-9]', ''), 3, 3) || '-' ||
                    SUBSTR(REGEXP_REPLACE(SUBSTR(l.localizacao_loja, INSTR(l.localizacao_loja, ',', 1, 4) + 5), '[^0-9]', ''), 6, 3) -- Formato XX.XXX-XXX
                ELSE 
                    NULL -- ou um valor padrão
            END AS cd_cep
        FROM Loja l;
    END etl_dim_loja;

    -- Procedure para carregar a Dimensão Tempo
    PROCEDURE etl_dim_tempo IS
    BEGIN
        INSERT INTO Dim_Tempo (id_tempo, dt_periodo, dt_data, dt_mes, dt_ano, dt_trimestre, dt_dia)
        SELECT DISTINCT
            v.venda_id,
            CASE 
                WHEN TO_NUMBER(TO_CHAR(v.data_venda, 'HH24')) BETWEEN 5 AND 11 THEN 'Manhã'
                WHEN TO_NUMBER(TO_CHAR(v.data_venda, 'HH24')) BETWEEN 12 AND 17 THEN 'Tarde'
                ELSE 'Noite'
            END AS dt_periodo,   
            TO_CHAR(v.data_venda, 'DD-MM-YY'),
            EXTRACT(MONTH FROM v.data_venda), 
            EXTRACT(YEAR FROM v.data_venda),
            CASE 
                WHEN EXTRACT(MONTH FROM v.data_venda) IN (1, 2, 3) THEN 1
                WHEN EXTRACT(MONTH FROM v.data_venda) IN (4, 5, 6) THEN 2
                WHEN EXTRACT(MONTH FROM v.data_venda) IN (7, 8, 9) THEN 3
                ELSE 4
            END AS dt_trimestre,
            EXTRACT(DAY FROM v.data_venda)
        FROM Venda v;
    END etl_dim_tempo;

    -- Procedure para carregar a Tabela Fato Vendas
    PROCEDURE etl_fato_vendas IS
    BEGIN
        INSERT INTO Fato_Vendas (id_fato, id_produto, id_cliente, id_loja, id_tempo, qt_vendas, vl_total_vendas)
        SELECT DISTINCT
            v.venda_id,
            v.produto_id,
            v.cliente_id,
            vl.loja_id, 
            v.venda_id,
            v.quantidade, 
            v.valor_total
    FROM Venda v
    JOIN Vendas_Loja vl ON v.venda_id = vl.venda_id -- Assumindo que há uma relação entre Venda e Vendas_Loja
    JOIN Produto p ON v.produto_id = p.produto_id;
    END etl_fato_vendas;
END pkg_etl_dimensional;
/