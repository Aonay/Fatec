CREATE OR REPLACE PACKAGE pkg_etl_dimensional AS

    PROCEDURE etl_dim_produto;
    PROCEDURE etl_dim_cliente;
    PROCEDURE etl_dim_loja;
    PROCEDURE etl_dim_tempo;
    PROCEDURE etl_fato_vendas;

END pkg_etl_dimensional;
/
