-- Tabela Dimensão Produto
CREATE TABLE Dim_Produto (
    id_produto INT PRIMARY KEY,
    nm_produto VARCHAR(100),
    nm_categoria VARCHAR(50),
    nm_marca VARCHAR(50),
    vl_preco DECIMAL(10,2)
) TABLESPACE usuariots;

-- Tabela Dimensão Cliente
CREATE TABLE Dim_Cliente (
    id_cliente INT PRIMARY KEY,
    nm_cliente VARCHAR(50),
    nm_email VARCHAR(100),
    dt_cadastro DATE --Todas as datas serão formatadas no Select para DD-MM-YY
) TABLESPACE usuariots;

-- Tabela Dimensão Loja
CREATE TABLE Dim_Loja (
    id_loja INT PRIMARY KEY,
    nm_loja VARCHAR(100),
    ds_endereco VARCHAR(100),
    nm_regiao VARCHAR(50),
    cd_cep VARCHAR(11) --Qtd de caracteres junto com os "." do CEP
) TABLESPACE usuariots;

-- Tabela Dimensão Tempo
CREATE TABLE Dim_Tempo (
    id_tempo INT PRIMARY KEY,
    dt_periodo VARCHAR(10),
    dt_data DATE,
    dt_mes INT,
    dt_ano INT,
    dt_trimestre INT,
    dt_dia INT
) TABLESPACE usuariots;

-- Tabela Fato Vendas
CREATE TABLE Fato_Vendas (
    id_fato INT PRIMARY KEY, --Criação do ID pra Fato
    id_produto INT,
    id_cliente INT,
    id_loja INT,
    id_tempo INT,
    qt_vendas INT,
    vl_total_vendas DECIMAL(10,2),
    FOREIGN KEY (id_produto) REFERENCES Dim_Produto(id_produto),
    FOREIGN KEY (id_cliente) REFERENCES Dim_Cliente(id_cliente),
    FOREIGN KEY (id_loja) REFERENCES Dim_Loja(id_loja),
    FOREIGN KEY (id_tempo) REFERENCES Dim_Tempo(id_tempo)
) TABLESPACE usuariots;
