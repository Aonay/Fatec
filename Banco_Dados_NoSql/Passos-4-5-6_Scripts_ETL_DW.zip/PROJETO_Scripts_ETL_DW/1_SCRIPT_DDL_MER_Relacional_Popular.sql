-- VERIFICADO | Inserindo registros na tabela Produto
INSERT INTO Produto (produto_id, nome_produto, categoria, marca, preco) VALUES
(1, 'Notebook Dell XPS', 'Eletrônicos', 'Dell', 8500.00);
INSERT INTO Produto (produto_id, nome_produto, categoria, marca, preco) VALUES
(2, 'Smartphone Samsung Galaxy', 'Eletrônicos', 'Samsung', 4000.00);
INSERT INTO Produto (produto_id, nome_produto, categoria, marca, preco) VALUES
(3, 'Geladeira Brastemp', 'Eletrodomésticos', 'Brastemp', 3000.00);

-- VERIFICADO | Inserindo registros na tabela Cliente
INSERT INTO Cliente (cliente_id, nome_cliente, email, data_cadastro) VALUES
(1, 'João Silva', 'joao.silva@email.com', TO_DATE('2023-01-10', 'YYYY-MM-DD'));
INSERT INTO Cliente (cliente_id, nome_cliente, email, data_cadastro) VALUES
(2, 'Maria Oliveira', 'maria.oliveira@email.com', TO_DATE('2023-03-15', 'YYYY-MM-DD'));
INSERT INTO Cliente (cliente_id, nome_cliente, email, data_cadastro) VALUES
(3, 'Carlos Souza', 'carlos.souza@email.com', TO_DATE('2023-05-20', 'YYYY-MM-DD'));

-- VERIFICADO | Inserindo registros na tabela Loja
INSERT INTO Loja (loja_id, nome_loja, localizacao_loja) VALUES
(1, 'Loja Centro', 'Rua das Flores, Bairro Centro, São Paulo, Região Sudeste, CEP 12345-678');
INSERT INTO Loja (loja_id, nome_loja, localizacao_loja) VALUES
(2, 'Loja Norte', 'Avenida das Palmeiras, Bairro Norte, Rio de Janeiro, Região Sudeste, CEP 12345-678');
INSERT INTO Loja (loja_id, nome_loja, localizacao_loja) VALUES
(3, 'Loja Sul', 'Rua ABC, Bairro XYZ, Santos, Região Sul, CEP 12345678');

-- VERIFICADO | Inserindo registros na tabela Venda
INSERT INTO Venda (venda_id, data_venda, cliente_id, produto_id, quantidade, valor_total) VALUES
(1, TO_DATE('2024-01-15 10:30:00', 'YYYY-MM-DD HH24:MI:SS'), 1, 1, 2, (SELECT preco FROM Produto WHERE produto_id = 1) * 2);
INSERT INTO Venda (venda_id, data_venda, cliente_id, produto_id, quantidade, valor_total) VALUES
(2, TO_DATE('2024-02-20 22:45:00', 'YYYY-MM-DD HH24:MI:SS'), 2, 2, 1, (SELECT preco FROM Produto WHERE produto_id = 2) * 1);
INSERT INTO Venda (venda_id, data_venda, cliente_id, produto_id, quantidade, valor_total) VALUES
(3, TO_DATE('2024-03-05 17:25:00', 'YYYY-MM-DD HH24:MI:SS'), 3, 3, 1, (SELECT preco FROM Produto WHERE produto_id = 3) * 1);

-- VERIFICADO | Inserindo registros na tabela Venda_Loja
INSERT INTO Vendas_Loja (loja_id, venda_id) VALUES (1, 1);
INSERT INTO Vendas_Loja (loja_id, venda_id) VALUES (1, 2);
INSERT INTO Vendas_Loja (loja_id, venda_id) VALUES (2, 3);