BEGIN
    pkg_etl_dimensional.etl_dim_produto;
    pkg_etl_dimensional.etl_dim_cliente;
    pkg_etl_dimensional.etl_dim_loja;
    pkg_etl_dimensional.etl_dim_tempo;
    pkg_etl_dimensional.etl_fato_vendas;
END;
/