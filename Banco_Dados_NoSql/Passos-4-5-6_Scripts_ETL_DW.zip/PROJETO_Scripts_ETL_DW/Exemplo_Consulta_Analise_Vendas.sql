-- Análise de Vendas por Produto e Loja
SELECT 
    p.nm_produto AS Nome_Produto,       -- Nome do produto
    l.nm_loja AS Nome_Loja,             -- Nome da loja
    SUM(f.qt_vendas) AS Total_Quantidade, -- Total de vendas
    SUM(f.vl_total_vendas) AS Total_Valor -- Valor total das vendas
FROM 
    Fato_Vendas f                         -- Tabela de vendas
JOIN 
    Dim_Produto p ON f.id_produto = p.id_produto -- Junção com Dimensão Produto
JOIN 
    Dim_Loja l ON f.id_loja = l.id_loja -- Junção com Dimensão Loja
GROUP BY 
    p.nm_produto, l.nm_loja              -- Agrupamento por produto e loja
ORDER BY 
    Total_Valor DESC;
