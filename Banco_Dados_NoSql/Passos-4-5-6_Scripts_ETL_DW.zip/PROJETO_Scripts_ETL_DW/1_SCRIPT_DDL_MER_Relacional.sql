-- Tabela Produto
CREATE TABLE Produto (
    produto_id INT PRIMARY KEY,
    nome_produto VARCHAR(100) NOT NULL,
    categoria VARCHAR(50) NOT NULL,
    marca VARCHAR(50) NOT NULL,
    preco DECIMAL(10, 2) NOT NULL
) TABLESPACE usuariots;

CREATE TABLE Cliente(
    cliente_id INT PRIMARY KEY,
    nome_cliente VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    data_cadastro DATE NOT NULL
) TABLESPACE usuariots;

-- Tabela Loja
CREATE TABLE Loja (
    loja_id INT PRIMARY KEY,
    nome_loja VARCHAR(100) NOT NULL,
    localizacao_loja VARCHAR(200) NOT NULL
) TABLESPACE usuariots;

-- Tabela Venda
CREATE TABLE Venda (
    venda_id INT PRIMARY KEY,
    data_venda DATE NOT NULL,
    cliente_id INT NOT NULL,
    produto_id INT NOT NULL,
    quantidade INT NOT NULL,
    valor_total DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (cliente_id) REFERENCES Cliente(cliente_id),
    FOREIGN KEY (produto_id) REFERENCES Produto(produto_id)
) TABLESPACE usuariots;

CREATE TABLE Vendas_Loja(
    loja_id INT,
    venda_id INT,
    FOREIGN KEY (loja_id) REFERENCES Loja(loja_id),
    FOREIGN KEY (venda_id) REFERENCES Venda(venda_id)
) TABLESPACE usuariots;